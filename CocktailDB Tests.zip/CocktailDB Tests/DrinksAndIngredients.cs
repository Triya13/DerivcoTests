﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CockTails
{
    public partial class Ingredient
    {
        public IngredientElement[] Ingredients { get; set; }
    }

    public partial class IngredientElement
    {
        public long IdIngredient { get; set; }
        public string StrIngredient { get; set; }
        public string StrDescription { get; set; }
        public string StrType { get; set; }
        public string StrAlcohol { get; set; }
        public long StrAbv { get; set; }
        public HttpStatusCode StatusCode { get; set; }
    }

    public partial class Drinks
    {
        public long IdDrink { get; set; }
        public string StrDrink { get; set; }
        public object StrDrinkAlternate { get; set; }
        public string StrTags { get; set; }
        public object StrVideo { get; set; }
        public string StrCategory { get; set; }
        public string StrIba { get; set; }
        public string StrAlcoholic { get; set; }
        public string StrGlass { get; set; }
        public string StrInstructions { get; set; }
        public object StrInstructionsEs { get; set; }
        public string StrInstructionsDe { get; set; }
        public object StrInstructionsFr { get; set; }
        public HttpStatusCode StatusCode { get; set; }


    }
}
