﻿using CockTails;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cocktails

{
    public class DrinkIngredient
    {
        public IngredientElement Get_Drink_Indredient(string ingredientName)
        {
            var restClient = new RestClient("https://www.thecocktaildb.com/api.php");
            var restRequest = new RestRequest("search.php", Method.Get);
            restRequest.AddParameter("i", ingredientName); 

            restRequest.AddHeader("Accept", "application/json");
            restRequest.RequestFormat = DataFormat.Json;

            RestResponse response = restClient.Execute(restRequest);
            //HttpStatusCode statusCode = response.StatusCode;
            var content = response.Content;

            var ingredient = JsonConvert.DeserializeObject<IngredientElement>(content);
            return ingredient;
        }

        public Drinks Get_Drink_Name()
        {
            var restClient = new RestClient("https://www.thecocktaildb.com/api.php");
            var restRequest = new RestRequest("www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita", Method.Get);

            restRequest.AddHeader("Accept", "application/json");
            restRequest.RequestFormat = DataFormat.Json;

            RestResponse response = restClient.Execute(restRequest);
            //HttpStatusCode statusCode = response.StatusCode;
            var content = response.Content;

            var drinks = JsonConvert.DeserializeObject<Drinks>(content);
            return drinks;
        }
    
    }

    
}
